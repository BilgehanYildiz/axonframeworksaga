package com.example.ordersaga.projector;

import com.example.saga.events.OrderCompensatedEvent;
import com.example.saga.events.OrderCreatedEvent;
import com.example.ordersaga.model.OrderEntity;
import com.example.ordersaga.repository.OrderRepository;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class OrderProjection {

    @Autowired
    private OrderRepository orderRepository;

    @EventHandler
    public void on(OrderCreatedEvent event) {
        System.out.println("order entity yaratıldı"+event.orderId);
        OrderEntity entity=new OrderEntity();
        entity.setOrderId(event.orderId);
        entity.setTestId(event.testId);
        entity.setDescription(event.description);

        orderRepository.save(entity);
    }

    @EventHandler
    public void on(OrderCompensatedEvent event) {
        System.out.println("order cancel edildi yaratıldı"+event.orderId);
        Optional<OrderEntity> orderEntityOptional =orderRepository.findById(event.orderId);
        if(orderEntityOptional.isPresent())
        {
            OrderEntity entity=  orderEntityOptional.get();
            entity.setDescription("Order cancel edildi");
            orderRepository.save(entity);
        }


    }
}
