package com.example.ordersaga;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrdersagaApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrdersagaApplication.class, args);
	}

}
