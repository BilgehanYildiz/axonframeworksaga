package com.example.ordersaga.bll;

import com.example.ordersaga.repository.OrderRepository;
import com.example.saga.command.CompensateOrderCommand;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.eventsourcing.eventstore.EventStore;
import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Service
public class OrderService {

    private final CommandGateway commandGateway;

    private final EventStore eventStore;

    private final OrderRepository orderRepository;


    public OrderService(CommandGateway commandGateway,EventStore eventStore,OrderRepository repository) {
        this.commandGateway = commandGateway;
        this.eventStore=eventStore;
        this.orderRepository=repository;
    }


    public String cancelOrder(String id)
    {
        try{
            String testid= orderRepository.findById(id).get().getTestId();
            CompletableFuture<Object> result= commandGateway.send(new CompensateOrderCommand(id,testid));
            return "Cancel icin istek yapıldı";
        }
        catch (Exception ex)
        {
            System.out.println("Command error");
        }
        return "";
    }

}
