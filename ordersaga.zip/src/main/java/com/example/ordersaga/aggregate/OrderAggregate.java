package com.example.ordersaga.aggregate;

import com.example.saga.command.CompensateOrderCommand;
import com.example.saga.command.CreateOrderCommand;
import com.example.saga.events.OrderCompensatedEvent;
import com.example.saga.events.OrderCreatedEvent;
import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;

@Aggregate
public class OrderAggregate {
    @AggregateIdentifier
    private String orderId;

    private String testId;

    private String description;

    public OrderAggregate() {
    }

    @CommandHandler
    public OrderAggregate(CreateOrderCommand createOrderCommand){
        AggregateLifecycle.apply(new OrderCreatedEvent(createOrderCommand.orderId,createOrderCommand.description, createOrderCommand.testId));
    }

    @EventSourcingHandler
    protected void on(OrderCreatedEvent orderCreatedEvent){
        this.testId = orderCreatedEvent.testId;
        this.orderId = orderCreatedEvent.orderId;
        this.description = orderCreatedEvent.description;
    }

    @CommandHandler
    public void compensateTestAggregate(CompensateOrderCommand command)
    {
        AggregateLifecycle.apply(new OrderCompensatedEvent(command.orderId,command.testId));
    }

    @EventSourcingHandler
    protected void on(OrderCompensatedEvent orderCompensatedEvent){

        this.orderId=orderCompensatedEvent.orderId;
        this.testId=orderCompensatedEvent.testId;
    }
}
