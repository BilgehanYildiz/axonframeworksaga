package com.example.ordersaga.controller;

import com.example.ordersaga.bll.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping(path = "/cancel/{orderid}")
    public ResponseEntity<String> cancelOrder(@PathVariable String orderid)
    {
        String eventid= orderService.cancelOrder(orderid);
        return ResponseEntity.status(HttpStatus.OK).body("order cancel edildi"+eventid);

    }
}
