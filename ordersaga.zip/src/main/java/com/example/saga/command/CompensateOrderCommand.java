package com.example.saga.command;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

public class CompensateOrderCommand {

    @TargetAggregateIdentifier
    public final String orderId;
    public final String testId;

    public CompensateOrderCommand(String orderId, String testId)
    {
        this.orderId=orderId;

        this.testId=testId;
    }
}
